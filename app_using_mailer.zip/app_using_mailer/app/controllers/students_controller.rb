class StudentsController < ApplicationController
    def create
      @student = Student.new(student_params)
  
      if @student.save
        StudentMailer.registration_confirmation(@student).deliver_now
        render json: { message: 'Student registered successfully' }, status: :created
      else
        render json: { errors: @student.errors.full_messages }, status: :unprocessable_entity
      end
    end
  
    private
  
    def student_params
      params.permit(:name, :email)
    end

  end
  