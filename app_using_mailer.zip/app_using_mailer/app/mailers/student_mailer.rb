
class StudentMailer < ApplicationMailer
    default from: 'shivanidayma61@gmail.com' 

    def registration_confirmation(student)
        @student = student
        attachments.inline['s.jpg'] = File.read('/home/dell/Downloads/s.jpg')

        mail(to: @student.email, subject: 'Registration Confirmation')
    end
end
  